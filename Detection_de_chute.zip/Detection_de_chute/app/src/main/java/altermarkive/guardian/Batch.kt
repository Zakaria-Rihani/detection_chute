package altermarkive.guardian

import android.content.ContentValues

class Batch(internal val table: String, internal val content: ContentValues)